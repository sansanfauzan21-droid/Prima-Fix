

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Contact Form Details</h5>
                    <a href="<?php echo e(route('contact-form.index')); ?>" class="btn btn-secondary">Back</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Name:</h6>
                            <p><?php echo e($contactForm->name); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Email:</h6>
                            <p><?php echo e($contactForm->email); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Subject:</h6>
                            <p><?php echo e($contactForm->subject); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Date:</h6>
                            <p><?php echo e($contactForm->created_at->format('d M Y H:i')); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h6>Message:</h6>
                            <p><?php echo e(nl2br(e($contactForm->message))); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <h6>Status:</h6>
                            <?php if($contactForm->is_read): ?>
                                <span class="badge bg-success">Read</span>
                            <?php else: ?>
                                <span class="badge bg-warning">Unread</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-main\resources\views/backend/utilities/contact-form/show.blade.php ENDPATH**/ ?>