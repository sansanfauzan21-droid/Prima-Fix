<?php $__currentLoopData = $paginatedActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="timeline-item mb-4" style="position: relative;">
        <div class="timeline-marker" style="position: absolute; left: -45px; top: 0; width: 20px; height: 20px; border-radius: 50%; background: <?php echo e($activity['color']); ?>; border: 3px solid white; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
            <i class="<?php echo e($activity['icon']); ?>" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 10px; color: white;"></i>
            <?php if(isset($activity['read']) && !$activity['read'] && $activity['type'] == 'Contact Form'): ?>
                <span class="notification-badge" style="position: absolute; top: -5px; right: -5px; width: 12px; height: 12px; background: #ff4757; border-radius: 50%; border: 2px solid white; animation: pulse 2s infinite;"></span>
            <?php endif; ?>
        </div>
        <?php if($activity['type'] == 'Contact Form' && isset($activity['id'])): ?>
            <a href="<?php echo e(route('contact-form.show', $activity['id'])); ?>" class="text-decoration-none">
                <div class="timeline-content hover-lift" style="background: white; padding: 15px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid <?php echo e($activity['color']); ?>; cursor: pointer; transition: transform 0.3s ease;">
                    <h6 class="timeline-title mb-2" style="color: #333; font-weight: 600;"><?php echo e($activity['type']); ?> <?php echo e($activity['action']); ?>

                        <?php if(isset($activity['read']) && !$activity['read']): ?>
                            <span class="badge bg-danger ms-2 pulse-badge" style="font-size: 0.7em; animation: pulse 2s infinite;">
                                <i class="bx bx-bell"></i> Baru
                            </span>
                        <?php endif; ?>
                    </h6>
                    <p class="timeline-text mb-2" style="color: #666; margin-bottom: 8px;"><?php echo e($activity['title']); ?></p>
                    <small class="text-muted d-flex align-items-center">
                        <i class="bx bx-time-five mr-1"></i>
                        <?php echo e($activity['time']); ?>

                        <i class="bx bx-link-external ms-auto text-primary"></i>
                    </small>
                </div>
            </a>
        <?php else: ?>
            <div class="timeline-content" style="background: white; padding: 15px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-left: 4px solid <?php echo e($activity['color']); ?>;">
                <h6 class="timeline-title mb-2" style="color: #333; font-weight: 600;"><?php echo e($activity['type']); ?> <?php echo e($activity['action']); ?></h6>
                <p class="timeline-text mb-2" style="color: #666; margin-bottom: 8px;"><?php echo e($activity['title']); ?></p>
                <small class="text-muted d-flex align-items-center">
                    <i class="bx bx-time-five mr-1"></i>
                    <?php echo e($activity['time']); ?>

                </small>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-mainNEW\laravel-compro-main\resources\views/backend/dashbord/partials/timeline.blade.php ENDPATH**/ ?>