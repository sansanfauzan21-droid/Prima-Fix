<?php $__env->startPush('hero'); ?>
    <section class="hero-section" id="hero">

        <div class="wave">

            <svg width="100%" height="355px" viewBox="0 0 1920 355" version="1.1" xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#FFFFFF">
                        <path
                            d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,757 L1017.15166,757 L0,757 L0,439.134243 Z"
                            id="Path"></path>
                    </g>
                </g>
            </svg>

        </div>

        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 hero-text-image">
                    <div class="row">
                        <div class="col-lg-8 text-center text-lg-start">
                            <h1 data-aos="fade-right"
    style="
        /* 1. Terapkan Background Gradient: Biru Tua ke Emas Pudar */
        background: -webkit-linear-gradient(top, #fd0000ff, #fc9608ff); /* WebKit */
        background: linear-gradient(to bottom, #ffe8c1ff, #eaa442ff); /* Standar */
        -webkit-background-clip: text;
        background-clip: text;

        /* 3. Jadikan teks transparan agar gradasi terlihat */
        -webkit-text-fill-color: transparent;
        color: transparent;

        /* Tambahkan font-weight atau font-size jika diperlukan */
        font-weight: bold;
    ">
    <?php echo e($heroTitle ? $heroTitle->content : 'Selamat Datang di Aliansi Profile'); ?>

</h1>
                            <p class="mb-5" data-aos="fade-right" data-aos-delay="100">
                                <?php echo e($heroSubtitle ? $heroSubtitle->content : 'STEP INTO THE FUTURE SAFELY.'); ?>

                            </p>
                            <style>
                            .btn-custom-hover {
                                padding: 10px 25px !important;
                                border: 2px solid #FFFFFF !important;
                                color: #FFFFFF !important;
                                background-color: transparent !important;
                                border-radius: 5px;
                                transition: all 0.3s ease;
                                /* PENAMBAHAN: Membuat teks lebih besar */
                                font-size: 1.2rem; /* Anda bisa coba 1.3rem, 1.4rem, dst. */
                            }

                            /* Gaya saat kursor melewatinya (Full Background Hover) */
                            .btn-custom-hover:hover {
                                background-color: #0d47a1 !important; /* Ganti dengan warna biru solid saat hover */
                                border-color: #ffae00ff !important; /* Border ikut warna biru */
                                color: #ffaa00ff !important; /* Pastikan teks tetap putih */
                                box-shadow: 0 4px 8px rgba(255, 196, 0, 0.99);
                            }
                            </style>
                         <p data-aos="fade-right" data-aos-delay="200" data-aos-offset="-500">
                        <a href="#main"
                        class="btn btn-outline-white btn-custom-hover">Mulai</a>
                         </p>
                        </div>
                        <div class="col-lg-4 text-center text-lg-end">
                            <img src="<?php echo e(asset('assets/img/logo.png')); ?>"
                                alt="Hero Image" data-aos="fade-right"
                                style="object-fit: contain; width: 350px; height: 350px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.home.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-mainNEW\laravel-compro-main\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>