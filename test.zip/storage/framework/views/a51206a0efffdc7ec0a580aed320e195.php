

<?php $__env->startSection('title', 'Unauthorized'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 text-center">
    <h1 class="display-1 text-danger">403</h1>
    <h3>Anda tidak mempunyai akses untuk mengubah isi content ini.</h3>
    <p>Silakan hubungi administrator jika Anda memerlukan akses ini.</p>
    <a href="/dashboard" class="btn btn-primary mt-3">Kembali ke Dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-mainNEW\laravel-compro-main\resources\views/errors/403.blade.php ENDPATH**/ ?>