

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard.index')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home-content.index')); ?>">Home Content Sections</a>
            </li>
            <li class="breadcrumb-item active">Edit <?php echo e($humanReadableTitle); ?></li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <h5 class="card-header">Edit Konten: <?php echo e($humanReadableTitle); ?></h5>
                <div class="card-body">
                    <form action="<?php echo e(route('home-content.update.section', $content->section)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="content">Isi Konten</label>
                            <div class="col-sm-10">
                                <textarea
                                    name="content"
                                    id="content"
                                    class="form-control"
                                    rows="5"
                                    placeholder="Masukkan isi konten..."
                                    required
                                ><?php echo e(old('content', $content->content)); ?></textarea>
                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-10">
                                <div class="form-check">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        name="status"
                                        id="status"
                                        value="1"
                                        <?php echo e(old('status', $content->status) ? 'checked' : ''); ?>

                                    >
                                    <label class="form-check-label" for="status">
                                        Aktif (Tampilkan di Frontend)
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-2"></div>
                            <div class="col-sm-10">
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                <a href="<?php echo e(route('home-content.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-mainNEW\laravel-compro-main\resources\views/backend/home/content/edit.blade.php ENDPATH**/ ?>