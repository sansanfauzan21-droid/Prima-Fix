<footer class="footer" role="contentinfo">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <h3>About
                    <?php echo e(CompanyHelper::get() && CompanyHelper::get()['nickname'] ? CompanyHelper::get()['nickname'] : 'PT. Aliansi Prima Energi'); ?>

                </h3>
                <p><?php echo e(CompanyHelper::description() ?? '...'); ?></p>
                <p class="social">
                    <?php if(FooterHelper::socialMedia()->count()): ?>
                        <?php $__currentLoopData = FooterHelper::socialMedia(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($item->url); ?>" target="_blank"><span class="<?php echo e($item->icon); ?>"></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="col-md-7 ms-auto">
                <div class="row site-section pt-0">
                    <div class="col-md-8 mb-4 mb-md-0 ms-auto">
                        
                        <ul class="list-unstyled">
                            <?php if(FooterHelper::navigation()->count()): ?>
                                <?php $__currentLoopData = FooterHelper::navigation(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e($item->url); ?>" target="_blank"><?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row justify-content-center text-center">
            <div class="col-md-7">
                
                
            </div>
        </div>

    </div>
</footer>
<?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-main\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>