

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-style1">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.index')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active">Home Content Sections</li>
            </ol>
        </nav>
        <div class="card">
            <h5 class="card-header"><?php echo e($title); ?></h5>
            
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="text-left" style="width: 30%;">
                                Nama Bagian (Section)
                            </th>
                            <th class="text-left" style="width: 40%;">
                                Pratinjau Konten
                            </th>
                            <th class="text-left" style="width: 15%;">
                                Status
                            </th>
                            <th class="text-center" style="width: 15%;">
                                Aksi
                            </th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $contentData = $contents[$section] ?? null;
                                $humanReadableTitle = Str::title(str_replace('_', ' ', $section)); 
                                
                                $statusActive = $contentData && $contentData->status;
                                $statusText = $statusActive ? 'Aktif' : 'Non-aktif';
                                $statusClass = $statusActive ? 'bg-label-success' : 'bg-label-secondary';

                                // Mengambil isi konten, menghapus tag HTML, dan memotongnya
                                $contentValue = $contentData ? $contentData->content : null;
                                $fullContent = $contentValue ? strip_tags($contentValue) : null; 
                                $contentPreview = $fullContent ? Str::limit($fullContent, 50) : null; 
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($humanReadableTitle); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($section); ?></small>
                                </td>
                                
                                
                                <td>
                                    <?php if($fullContent): ?>
                                    <span 
                                        data-bs-toggle="tooltip" 
                                        data-bs-placement="top" 
                                        title="<?php echo e($fullContent); ?>"
                                        style="cursor: help;"
                                    >
                                        <?php echo e($contentPreview); ?>

                                        <?php if(strlen($fullContent) > 50): ?>
                                            ...
                                        <?php endif; ?>
                                    </span>
                                    <?php else: ?>
                                        <em class="text-warning">Konten belum diisi.</em>
                                    <?php endif; ?>
                                </td>
                                
                                <td>
                                    <?php if($contentData): ?>
                                    <span class="badge <?php echo e($statusClass); ?>"><?php echo e($statusText); ?></span>
                                    <?php else: ?>
                                    <span class="badge bg-label-info">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('home-content.edit.section', $section)); ?>"
                                       class="btn btn-sm btn-icon btn-outline-primary"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="top"
                                       title="Edit Konten">
                                        <i class="bx bx-edit-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    
    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Inisialisasi Tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-main\resources\views/backend/home/content/index.blade.php ENDPATH**/ ?>