

<?php $__env->startSection('title', 'Regulations'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <!-- Basic Breadcrumb -->
        <nav aria-label="breadcrumb mx-1">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('dashboard.index')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active">Regulations</li>
            </ol>
        </nav>
        <!-- Basic Breadcrumb -->

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Regulations</h3>
                <a href="<?php echo e(route('regulations.create')); ?>" class="btn btn-primary">Add Regulation</a>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Nomer</th>
                                <th>Nama Pasal</th>
                                <th>Tanggal</th>
                                <th>Dokumen</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $regulations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regulation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($regulation->id); ?></td>
                                    <td><?php echo e($regulation->nomer); ?></td>
                                    <td><?php echo e($regulation->nama_pasal); ?></td>
                                    <td><?php echo e($regulation->tanggal); ?></td>
                                    <td>
                                        <?php if($regulation->dokumen): ?>
                                            <a href="<?php echo e(asset('storage/dokumen/' . $regulation->dokumen)); ?>" target="_blank" class="btn btn-sm btn-info">
                                                <i class="fas fa-file-pdf"></i> View PDF
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">No file</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($regulation->created_at->format('d M Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('regulations.edit', $regulation->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <form action="<?php echo e(route('regulations.destroy', $regulation->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this regulation?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">No regulations found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PT ALIANSI PRIMA ENERGI\laravel-compro-main\resources\views/backend/regulations/index.blade.php ENDPATH**/ ?>